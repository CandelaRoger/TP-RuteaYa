﻿
using RuteaYa.DTOs;

namespace RuteaYa.Logica
{
    public interface IOportunidadService
    {
        
        Task<ResultadoOperacion<bool>> AceptarEnvioAsync(
            int viajeId,
            int envioId,
            int usuarioId);
        Task<List<OportunidadDto>> ObtenerAsignadosAsync(
    int viajeId,
    int usuarioId);
        Task<CapacidadViajeDto> ObtenerCapacidadAsync(
    int viajeId,
    int usuarioId);
        Task<ResultadoOperacion<bool>> QuitarEnvioAsync(
    int viajeId,
    int envioId,
    int usuarioId);

        Task<List<OportunidadDto>> ObtenerCandidatosAsync(
    int viajeId,
    int usuarioId,
    string? orden = "ganancia");
    
    Task<List<OportunidadDto>> ObtenerCandidatosPorFechaAsync(
    int viajeId,
    int usuarioId,
    DateTime fecha,
    string? orden = "ganancia");

        Task<ResultadoOperacion<ResumenSeleccionDto>> PrevisualizarSeleccionAsync(
    int viajeId, List<int> envioIds, int usuarioId);

        Task<ResultadoOperacion<bool>> ConfirmarSeleccionAsync(
            int viajeId, List<int> envioIds, int usuarioId);

    }
}